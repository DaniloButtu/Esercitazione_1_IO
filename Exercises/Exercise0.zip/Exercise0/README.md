# Input/Output

## Exercise 0: 

A project template.

